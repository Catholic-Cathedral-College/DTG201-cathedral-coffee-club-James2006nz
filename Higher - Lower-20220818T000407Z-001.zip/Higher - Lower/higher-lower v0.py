#secret number (Higher Lower) game
#establishing variables and background information
from random import randint
high_num == int(input("What is the highest value you would like for your secret number? "))
low_number == int(input("What is the lowest value you would like for your secret number? "))
num_rounds == int(input("How many rounds would you like to play? "))
num_guesses == int(input("How many attempts would you like to guess your secret number? "))
