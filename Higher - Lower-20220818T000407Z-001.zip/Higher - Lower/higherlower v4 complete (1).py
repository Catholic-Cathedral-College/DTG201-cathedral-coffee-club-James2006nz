#secret number (Higher Lower) game
#establishing variables and background information
from random import randint
from time import sleep
high_num = int(input("What is the highest value you would like for your secret number? "))
low_num = int(input("What is the lowest value you would like for your secret number? "))
num_rounds = int(input("How many rounds would you like to play? "))
num_guess = int(input("How many attempts would you like to guess your secret number? "))
#game
while num_rounds >0:
    secret = randint(int(low_num), int(high_num))
    game = 1
    sleep(1)
    print("you have", (num_rounds), " rounds remaining")
    while game >0:
        guess = int(input("What do you think the secret number is? "))
        if guess < secret:
            print("Too low try again!")
        elif guess > secret:
            print("Too high try again!")
        num_guess = num_guess -1
        if guess == secret:
            print("That's right well done!, the secret number was ", (secret))
            game = 0
            num_rounds = num_rounds -1
            print("You had ", num_guess, "guesses remaining")
        if guess == 0:
            print("Nice try, unfortunately you ran out of guesses and didn't get it correct, better luck next time. The secret number was ", (secret))
            game = 0
            num_rounds = num_rounds -1
            print("You had no guesses remaining")